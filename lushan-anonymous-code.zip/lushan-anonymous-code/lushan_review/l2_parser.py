"""Frozen deterministic extraction for the DentVLM / Qwen2-VL paired protocol.

Coordinates always use the requested 0..1000 image-relative unit. Extraction
has no access to labels, masks, model identity, or observed accuracy.
"""
import json
import math
import re


FDI = {10 * quadrant + tooth for quadrant in range(1, 5) for tooth in range(1, 9)}
NUMBER = re.compile(r"(?<![\w.])[+-]?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?(?!\w|\.\d)")
BRACKETS = re.compile(r"\[[^\[\]\n]*\]")
REFUSAL = re.compile(
    r"\b(?:cannot|can['’]t|unable\s+to)\b.{0,50}\b(?:locate|located|find|found)\b"
    r"|\b(?:tooth|teeth)\s+(?:is|are)\s+(?:absent|missing|not\s+(?:visible|present))\b",
    re.IGNORECASE,
)


def unique_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate_json_key")
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("nonfinite_json_constant")


def load_response(text):
    text = text.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        if len(lines) < 3 or lines[0].strip() not in ("```", "```json") or lines[-1].strip() != "```":
            return "invalid_json", None, text
        text = "\n".join(lines[1:-1]).strip()
    try:
        value = json.loads(text, object_pairs_hook=unique_keys, parse_constant=reject_constant)
        return "json", value, text
    except ValueError:
        if text.startswith("{"):
            return "invalid_json", None, text
        return "text", None, text


def fdi_value(value):
    if isinstance(value, str) and re.fullmatch(r"[1-4][1-8]", value):
        value = int(value)
    return value if type(value) is int and value in FDI else None


def structured_fdi(obj):
    carriers = []
    if "fdi" in obj:
        carriers.append(obj)
    if "identity" in obj:
        carriers.append(obj["identity"])
    if not carriers:
        return None
    values = []
    for item in carriers:
        if not isinstance(item, dict) or item.get("status", "answerable") != "answerable":
            return None
        value = fdi_value(item.get("fdi"))
        if value is None:
            return None
        values.append(value)
    return values[0] if len(set(values)) == 1 else None


def parse_fdi(text, joint=False):
    kind, obj, text = load_response(text)
    if kind == "invalid_json":
        return None
    if kind == "json":
        if isinstance(obj, dict):
            return structured_fdi(obj)
        return fdi_value(obj)
    if text.startswith("[") or re.search(
        r"cannot\s+(?:identify|determine)|insufficient_information", text, re.IGNORECASE
    ):
        return None
    # Joint-task point components must never be interpreted as tooth numbers.
    if joint:
        if not re.search(r"\bFDI\b", text, re.IGNORECASE):
            return None
        text = BRACKETS.sub("", text)
    numbers = NUMBER.findall(text)
    if not numbers or any(not re.fullmatch(r"[1-4][1-8]", number) for number in numbers):
        return None
    values = set(map(int, numbers))
    return values.pop() if len(values) == 1 else None


def valid_point(point):
    return (
        isinstance(point, list)
        and len(point) == 2
        and all(type(v) in (int, float) and math.isfinite(v) and 0 <= v < 1000 for v in point)
    )


def structured_point(obj):
    carriers = []
    if "pixel_xy" in obj:
        carriers.append(obj)
    if "localization" in obj:
        carriers.append(obj["localization"])
    if not carriers:
        return False, None
    values = []
    for item in carriers:
        if not isinstance(item, dict) or "pixel_xy" not in item:
            return False, None
        point = item["pixel_xy"]
        status = item.get("status")
        if status not in (None, "answerable", "insufficient_information"):
            return False, None
        if status == "answerable" and point is None:
            return False, None
        if status == "insufficient_information" and point is not None:
            return False, None
        if point is not None and not valid_point(point):
            return False, None
        values.append(point)
    if any(point != values[0] for point in values[1:]):
        return False, None
    return True, values[0]


def explicit_refusal(text):
    if not re.search(r"\b(?:target|tooth|teeth)\b", text, re.IGNORECASE):
        return False
    for clause in re.split(r"[.!?;\n]", text):
        # Conditional instructions are not assertions that this target is absent.
        if re.search(r"\b(?:if|unless|whether)\b|\bno\s+(?:evidence|indication|reason)\b", clause, re.IGNORECASE):
            continue
        if re.search(r"\bsource\b", clause, re.IGNORECASE) and not re.search(r"\btarget\b", clause, re.IGNORECASE):
            continue
        if REFUSAL.search(clause):
            return True
    return False


def normalized_point(text):
    kind, obj, text = load_response(text)
    if kind == "invalid_json":
        return False, None, "invalid_json"
    if kind == "json":
        if isinstance(obj, dict):
            valid, point = structured_point(obj)
            return valid, point, "json_fields" if valid else "invalid_or_conflicting_fields"
        if obj is None:
            return True, None, "explicit_null"
        if valid_point(obj):
            return True, obj, "json_point"
        return False, None, "invalid_point"
    if text.lower() == "insufficient_information":
        return True, None, "explicit_status"
    matches = BRACKETS.findall(text)
    refusal = explicit_refusal(text)
    if refusal:
        if matches:
            return False, None, "point_refusal_conflict"
        return True, None, "explicit_text_refusal"
    if not matches:
        # Preserve the development parser's unbracketed single-pair support.
        if re.fullmatch(r"\s*-?\d+(?:\.\d+)?\s*,\s*-?\d+(?:\.\d+)?\s*", text):
            matches = ["[" + text + "]"]
        else:
            return False, None, "no_unique_point"
    points = []
    for match in matches:
        try:
            point = json.loads(match, parse_constant=reject_constant)
        except ValueError:
            return False, None, "invalid_point"
        if not valid_point(point):
            return False, None, "invalid_point"
        points.append(point)
    if any(point != points[0] for point in points[1:]):
        return False, None, "conflicting_points"
    return True, points[0], "text_unique_point"


def parse_point(text):
    valid, point, _ = normalized_point(text)
    if not valid or point is None:
        return valid, None
    return True, [value * 0.512 for value in point]


def parse_response(text, task):
    if task not in ("fdi", "marker", "localization", "joint"):
        raise ValueError("unsupported_task")
    number = parse_fdi(text, joint=task == "joint") if task in ("fdi", "joint") else None
    valid, point, method = normalized_point(text) if task != "fdi" else (False, None, "not_requested")
    return {
        "fdi": number,
        "fdi_extractable": number is not None,
        "point_extractable": valid,
        "normalized_xy": point,
        "pixel_xy": [value * 0.512 for value in point] if valid and point is not None else None,
        "point_extraction": method,
    }
