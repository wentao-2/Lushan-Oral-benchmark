"""Camera projection and target-interior selection; no clinical inputs bundled."""
import hashlib
import json
import numpy as np
from scipy.ndimage import distance_transform_edt
W = 512
VERSION = 'grounding-dev-v2-geometry-1' 

def key(*args):
    return hashlib.sha256(json.dumps([VERSION, *args], separators=(',', ':')).encode()).hexdigest()


def rng(*args):
    return np.random.default_rng(int(key(*args)[:16], 16))


def rotation(x, y, z):
    a,b,c = np.deg2rad([x,y,z])
    rx = np.array([[1,0,0],[0,np.cos(a),-np.sin(a)],[0,np.sin(a),np.cos(a)]])
    ry = np.array([[np.cos(b),0,np.sin(b)],[0,1,0],[-np.sin(b),0,np.cos(b)]])
    rz = np.array([[np.cos(c),-np.sin(c),0],[np.sin(c),np.cos(c),0],[0,0,1]])
    r = rz @ ry @ rx
    assert abs(np.linalg.det(r)-1) < 1e-10
    return r


def projected(v, center, basis, rot, framing):
    # Bounds use the original full geometry, never the selected target or deletion.
    p=(v-center) @ basis @ rot.T
    lo=p[:,:2].min(0);hi=p[:,:2].max(0);mid=(lo+hi)/2
    scale=(W-1)*framing['fill']/max(hi-lo)
    xy=np.array(framing['center_px'])
    screen=p.copy();screen[:,0]=(p[:,0]-mid[0])*scale+xy[0]
    screen[:,1]=-(p[:,1]-mid[1])*scale+xy[1];screen[:,2]=p[:,2]*scale
    assert screen[:,:2].min()>=0 and screen[:,:2].max()<W
    a=basis @ rot.T @ np.diag([scale,-scale,scale])
    offset=np.array([xy[0]-mid[0]*scale,xy[1]+mid[1]*scale,0.])-center@a
    m=np.eye(4);m[:3,:3]=a.T;m[:3,3]=offset
    assert np.max(abs(v@a+offset-screen))<1e-8
    return screen,m


def frame(sid, role):
    r=rng(sid,'frame',role)
    fill=float(r.uniform(.58,.76))
    slack=(W-1)*(1-fill)/2-12
    xy=(np.array([255.5,255.5])+r.uniform(-slack,slack,size=2)).tolist()
    return {'fill':fill,'center_px':xy}


def interior(mask, iid):
    binary=mask==iid;area=int(binary.sum())
    if not area:return None,0.,0
    d=distance_transform_edt(binary);y,x=np.unravel_index(d.argmax(),d.shape)
    return [int(x),int(y)],float(d[y,x]),area
