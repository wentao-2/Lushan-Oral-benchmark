"""Frozen face-level instance and joint FDI scoring kernels."""
import numpy as np
from scipy.optimize import linear_sum_assignment
FDI = tuple(q * 10 + p for q in range(1, 9) for p in range(1, 9 if q < 5 else 6))

def require(value, message):
    if not value:
        raise AssertionError(message)


def ratio(n, d):
    return float(n / d) if d else None


def matching(truth, pred, valid):
    """Maximum admissible cardinality, then IoU. First-face order resolves ties."""
    require(truth.shape == pred.shape == valid.shape and truth.ndim == 1, 'face vector shapes')
    require(np.issubdtype(truth.dtype, np.integer) and np.issubdtype(pred.dtype, np.integer), 'integer instances')
    require(np.all(truth >= 0) and np.all(pred >= 0), 'negative instances')
    require(valid.dtype == np.bool_, 'boolean valid mask')
    gt, gf, gi = np.unique(truth[valid], return_index=True, return_inverse=True)
    pr, pf, pi = np.unique(pred[valid], return_index=True, return_inverse=True)
    gr = [i for i in np.argsort(gf, kind='stable') if gt[i] > 0]
    pc = [i for i in np.argsort(pf, kind='stable') if pr[i] > 0]
    gids, pids = [int(gt[i]) for i in gr], [int(pr[i]) for i in pc]
    require(len(gt) * len(pr) <= 4_000_000, 'too many instances')
    pairs = []
    if gr and pc:
        table = np.zeros((len(gt), len(pr)), np.int64)
        np.add.at(table, (gi, pi), 1)
        intersection = table[np.ix_(gr, pc)]
        union = table.sum(1)[gr, None] + table.sum(0)[None, pc] - intersection
        iou = intersection / union
        valid_iou = iou >= .5
        bonus = min(len(gr), len(pc)) + 1
        rr, cc = linear_sum_assignment(-np.where(valid_iou, bonus + iou, 0.))
        pairs = [dict(gt_id=gids[i], pred_id=pids[j], iou=float(iou[i, j]))
                 for i, j in zip(rr, cc) if valid_iou[i, j]]
    mg, mp = {r['gt_id'] for r in pairs}, {r['pred_id'] for r in pairs}
    return dict(gt_ids=gids, pred_ids=pids, matches=pairs,
                unmatched_gt=[x for x in gids if x not in mg],
                unmatched_pred=[x for x in pids if x not in mp])


def counts(tp, fp, fn, overlap):
    den = tp + .5 * (fp + fn)
    return dict(tp=int(tp), fp=int(fp), fn=int(fn), matched_iou_sum=float(overlap),
                precision=ratio(tp, tp + fp), recall=ratio(tp, tp + fn),
                f1=ratio(2 * tp, 2 * tp + fp + fn), sq=ratio(overlap, tp),
                rq=ratio(tp, den), pq=ratio(overlap, den))


def score(gt, ids, fdi, supernumerary, valid, prediction):
    """Original full cohort obeys the frozen unknown/supernumerary FDI void rule."""
    pred = np.asarray(prediction['face_instance'])
    pids, pfdi = prediction['instance_ids'], prediction['instance_fdi']
    require(len(ids) == len(fdi) == len(supernumerary), 'GT table lengths')
    require(len(pids) == len(pfdi), 'prediction table lengths')
    require(len(set(map(int, ids))) == len(ids) and np.all(ids > 0), 'GT IDs')
    require(len(set(map(int, pids))) == len(pids) and np.all(pids > 0), 'prediction IDs')
    require(set(map(int, pfdi)) <= {-1, *FDI} and set(map(int, fdi)) <= {-1, *FDI}, 'FDI values')
    require(set(map(int, pids)) <= set(map(int, np.unique(pred))) - {0}, 'unoccupied prediction metadata')
    require(set(map(int, np.unique(gt))) - {0} <= set(map(int, ids)), 'unmapped GT face')
    truth_map = {int(i): int(y) for i, y, extra in zip(ids, fdi, supernumerary) if not extra and y != -1}
    ignored = set(map(int, ids)) - set(truth_map)
    number_valid = valid.astype(bool).copy()
    if ignored:
        number_valid &= ~np.isin(gt, list(ignored))
    m = matching(gt, pred, number_valid)
    geom = matching(gt, pred, valid.astype(bool))
    pm = {int(i): int(y) for i, y in zip(pids, pfdi)}
    pairs = {r['gt_id']: r for r in m['matches']}
    teeth = []
    for i in m['gt_ids']:
        pair = pairs.get(i)
        y = pm.get(pair['pred_id'], -1) if pair else -1
        teeth.append(dict(instance_id=i, truth_fdi=truth_map[i], predicted_fdi=y,
                          matched=pair is not None, correct=bool(pair and y == truth_map[i]),
                          predicted_instance=pair['pred_id'] if pair else None,
                          iou=pair['iou'] if pair else None))
    correct = sum(x['correct'] for x in teeth)
    wrong = len(m['matches']) - correct
    fp, fn = len(m['unmatched_pred']) + wrong, len(m['unmatched_gt']) + wrong
    joint = counts(correct, fp, fn, sum(x['iou'] for x in teeth if x['correct']))
    joint.update(track='joint', iou_threshold=.5, correct_teeth=correct, scored_teeth=len(teeth),
                 excluded_gt_teeth=len(ignored), accuracy=ratio(correct, len(teeth)),
                 exact_scan_correct=(fp == 0 and fn == 0) if teeth else None,
                 wrong_number_matches=wrong, detection_matched_teeth=len(m['matches']))
    segmentation = counts(len(geom['matches']), len(geom['unmatched_pred']), len(geom['unmatched_gt']),
                          sum(x['iou'] for x in geom['matches']))
    return dict(correct=correct, total=len(teeth), accuracy=ratio(correct, len(teeth)), teeth=teeth,
                extra_instances=len(m['unmatched_pred']), geometry_matching=m,
                joint=joint, instance_segmentation=segmentation)


def retained_baseline(full, removed):
    removed = set(removed)
    teeth = [r for r in full['teeth'] if r['instance_id'] not in removed]
    return dict(correct=sum(x['correct'] for x in teeth), total=len(teeth),
                accuracy=ratio(sum(x['correct'] for x in teeth), len(teeth)), teeth=teeth,
                extra_instances=full['extra_instances'],
                basis='Original full-face matching; delete target teeth from tooth denominator only.')
