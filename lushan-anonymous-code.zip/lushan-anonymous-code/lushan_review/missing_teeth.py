"""Fixed deletion choices and face-preserving input variants."""
import hashlib
import itertools
import json
import numpy as np
TRAIN_TYPES = ('single_internal', 'adjacent_pair', 'separated_pair', 'adjacent_triple')
SELECTION_VERSION = 'missing-tooth-expanded-seed0-v1' 

def index_sha256(values):
    return hashlib.sha256(np.asarray(values, dtype='<i8').tobytes()).hexdigest()


def stable_hash(*parts):
    return hashlib.sha256(json.dumps(parts, ensure_ascii=False,
                                    separators=(',', ':')).encode('utf-8')).hexdigest()


def arch_slots(jaw):
    if jaw == 'upper':
        return list(range(18, 10, -1)) + list(range(21, 29))
    if jaw == 'lower':
        return list(range(48, 40, -1)) + list(range(31, 39))
    raise ValueError(f'Unknown jaw: {jaw}')


def deletion_candidates(present_fdi, jaw, minimum_remaining=6):
    """Anatomical slot adjacency, including the two central incisors."""
    slots = arch_slots(jaw)
    present = set(int(x) for x in present_fdi)
    result = {name: [] for name in TRAIN_TYPES}
    for width, name in ((1, 'single_internal'), (2, 'adjacent_pair'),
                        (3, 'adjacent_triple')):
        if len(present) - width < minimum_remaining:
            continue
        for start in range(1, len(slots) - width):
            window = slots[start:start + width]
            required = slots[start - 1:start + width + 1]
            if all(code in present for code in required):
                result[name].append(window)
    if len(present) - 2 >= minimum_remaining:
        singles = result['single_internal']
        for first, second in itertools.combinations(singles, 2):
            if abs(slots.index(first[0]) - slots.index(second[0])) >= 2:
                result['separated_pair'].append([first[0], second[0]])
    return result


def deterministic_candidate(scan_id, condition, candidates):
    if not candidates:
        return None
    return min(candidates, key=lambda value: stable_hash(
        SELECTION_VERSION, 'fixed-candidate', scan_id, condition, value))


def select_training_variant(scan_row, seed, epoch, draw_id=0):
    """Independent hash RNG: P(original)=1/2, P(each deletion request)=1/8.

    Unavailable requested types fall back to original without renormalizing the
    four-type distribution. It does not read or modify numpy/torch/Python RNG.
    draw_id disambiguates repeated visits of a scan within one epoch.
    """
    if scan_row['split'] != 'train':
        raise ValueError('Training augmentation may only select train scans')
    payload = (SELECTION_VERSION, 'train-variant', int(seed), int(epoch),
               str(scan_row['scan_id']), int(draw_id))
    digest = bytes.fromhex(stable_hash(*payload))
    requested = 'original' if (digest[0] & 1) == 0 else TRAIN_TYPES[digest[1] & 3]
    item = scan_row['conditions'][requested]
    selected = requested if item['available'] else 'original'
    selected_item = scan_row['conditions'][selected]
    return {'condition': selected, 'requested_condition': requested,
            'applied_type': selected, 'requested_type': requested,
            'augmented': selected != 'original',
            'fallback': selected != requested,
            'fallback_reason': None if selected == requested else item['unavailable_reason'],
            'delete_instance_ids': selected_item['delete_instance_ids'],
            'delete_fdi': selected_item['delete_fdi'],
            'seed': int(seed), 'epoch': int(epoch), 'draw_id': int(draw_id),
            'sampling_digest': digest.hex()}


def kept_original_face_ids(scan_row, condition):
    """Return increasing original face IDs; no remeshing, no label changes."""
    item = scan_row['conditions'][condition]
    if not item['available']:
        raise ValueError(f"Unavailable {scan_row['scan_id']}:{condition}: "
                         f"{item['unavailable_reason']}")
    if condition == 'original':
        keep = np.arange(int(scan_row['face_count']), dtype=np.int64)
    elif condition == 'partial_arch':
        with np.load(scan_row['geometry_npz'], allow_pickle=False) as geometry:
            vertices = np.asarray(geometry['vertices'], dtype=np.float64)
            faces = np.asarray(geometry['faces'], dtype=np.int64)
        centers = vertices[faces].mean(axis=1)
        normal = np.asarray(item['cut_plane_normal'], dtype=np.float64)
        point = np.asarray(item['cut_plane_point'], dtype=np.float64)
        signed = (centers - point) @ normal
        mask = signed >= 0.0 if item['keep_positive'] else signed <= 0.0
        keep = np.flatnonzero(mask).astype(np.int64)
    else:
        with np.load(scan_row['label_npz'], allow_pickle=False) as labels:
            instances = labels['face_instance']
        keep = np.flatnonzero(~np.isin(instances, item['delete_instance_ids'])).astype(np.int64)
    if len(keep) != item['remaining_face_count']:
        raise RuntimeError('Remaining original face count changed')
    if index_sha256(keep) != item['kept_original_face_ids_sha256']:
        raise RuntimeError('Original face mapping changed')
    return keep
