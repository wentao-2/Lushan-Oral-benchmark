"""Reaggregate frozen per-scan matches with the manuscript's reference-tooth rule.

CPU only: no model loading, prediction changes, rematching, or checkpoint selection.
Original score artifacts are read-only. The strict score is retained for comparison.
"""
from pathlib import Path
import argparse
import collections
import csv
import hashlib
import json


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def scan_flags(result):
    teeth = result['teeth']
    assert len(teeth) == result['total'] > 0
    correct = sum(bool(t['matched']) and t['truth_fdi'] == t['predicted_fdi'] for t in teeth)
    assert correct == result['correct'] == sum(t['correct'] for t in teeth)
    all_reference = correct == len(teeth)
    strict = all_reference and result['extra_instances'] == 0
    assert strict == bool(result['joint']['exact_scan_correct'])
    return all_reference, strict


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', type=Path, required=True)
    ap.add_argument('--plan', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    plan = json.loads(args.plan.read_text())
    scans = {r['scan_id']: r for r in plan['scans'] if r['split'] == 'test'}
    rows = []
    evidence = {'cpu_only': True, 'rule': 'Every scored reference tooth is correctly matched and numbered; extra predictions affect joint F1, not Scan Acc.',
                'dataset_plan_sha256': sha(args.plan), 'script_sha256': sha(Path(__file__)), 'runs': {}}
    for model in ['ptv3', 'tcatseg', 'utonia']:
        for regime in ['original', 'augmented']:
            run = f'{model}_{regime}_seed0'
            folder = args.root / 'scores' / run / 'test'
            records = json.loads((folder / 'per_scan.json').read_text())
            old = json.loads((folder / 'summary.json').read_text())['summary']
            official = json.loads((folder / 'fdi_numbering_official.json').read_text())
            complete = json.loads((folder / 'complete.json').read_text())
            assert complete['summary_sha256'] == sha(folder / 'summary.json')
            assert complete['manifest_sha256'] == sha(folder / 'manifest.json')
            assert len(records) == len(scans) == 532
            assert {r['scan_id'] for r in records} == set(scans)
            groups = collections.defaultdict(list)
            for record in records:
                spec = scans[record['scan_id']]
                assert set(record['conditions']) == {c for c, x in spec['conditions'].items() if x['available']}
                for condition, result in record['conditions'].items():
                    new_flag, strict_flag = scan_flags(result)
                    value = (new_flag, strict_flag, result)
                    groups[condition].append(value)
                    if condition == 'original' and spec['natural_gaps']['eligible_for_label_gap_interpretation']:
                        key = 'natural_internal_gap' if spec['natural_gaps']['gaps'] else 'eligible_without_internal_gap'
                        groups[key].append(value)
            for condition, values in groups.items():
                n = len(values)
                correct = sum(v[2]['correct'] for v in values)
                total = sum(v[2]['total'] for v in values)
                strict_count = sum(v[1] for v in values)
                count = sum(v[0] for v in values)
                previous = old[condition]
                assert n == previous['scans_or_variant_records']
                assert strict_count == previous['exact_scan_count']
                assert correct == previous['correct_teeth'] and total == previous['total_teeth']
                assert count >= strict_count
                # Independently reproduce unchanged count-based metrics from the archived matches.
                for task in ['joint', 'instance_segmentation']:
                    for k in ['tp', 'fp', 'fn']:
                        assert sum(v[2][task][k] for v in values) == previous[task][k]
                rows.append(dict(model=model, training=regime, seed=0, condition=condition,
                                 scans=n, correct_reference_scans=count, strict_correct_scans=strict_count,
                                 scan_accuracy=100*count/n, strict_scan_accuracy=100*strict_count/n,
                                 difference_pp=100*(count-strict_count)/n,
                                 tooth_accuracy=100*correct/total,
                                 joint_f1=100*previous['joint']['f1']))
            assert official['coverage']['present'] == 532
            assert abs(official['metrics']['exact_scan_accuracy'] - old['original']['exact_scan_count']/532) < 1e-12
            evidence['runs'][run] = {name: sha(folder / name) for name in ['per_scan.json', 'summary.json', 'manifest.json', 'complete.json', 'fdi_numbering_official.json']}
            print(run, 'original', next(r for r in rows if r['model']==model and r['training']==regime and r['condition']=='original'), flush=True)
    assert len(rows) == 48
    with (args.output / 'recent_l1_scan_accuracy.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    evidence['rows'] = rows
    (args.output / 'rescore_validation.json').write_text(json.dumps(evidence, indent=2)+'\n')


if __name__ == '__main__':
    main()
