"""Small CPU-only examples. All identifiers, labels, and masks are synthetic."""
import json
import numpy as np
from .splits import grouped_splits
from .missing_teeth import deletion_candidates
from .l1_scoring import score
from .l2_scoring import score_answer
from .l3_parser import parse


def main():
    groups, _ = grouped_splits([
        {'case_id': 'synthetic-a', 'mesh_key': 'synthetic-geometry'},
        {'case_id': 'synthetic-b', 'mesh_key': 'synthetic-geometry'}], [])
    truth = np.array([0, 0, 1, 1, 2, 2])
    ids, fdi = np.array([1, 2]), np.array([11, 21])
    pred = {'face_instance': truth.copy(), 'instance_ids': ids, 'instance_fdi': fdi}
    l1 = score(truth, ids, fdi, np.array([False, False]), np.ones(6, bool), pred)
    mask = np.zeros((512, 512), dtype=np.int32)
    mask[240:272, 240:272] = 2
    l2 = score_answer('{"fdi":21,"pixel_xy":[500,500]}', 'joint',
                      {'truth_fdi': 21, 'instance_id': 2, 'localization_answerable': True}, mask)
    candidates = deletion_candidates([18,17,16,15,14,13,12,11,21,22,23,24,25,26,27,28], 'upper')
    print(json.dumps({'synthetic_examples_only': True, 'grouped_splits': groups,
                      'removal_candidate_counts': {k: len(v) for k, v in candidates.items()},
                      'l1_joint': l1['joint'], 'l2_joint_response': l2,
                      'l3_chosen_option': parse('Answer: 2', ['Rotation present', 'No obvious rotation'])},
                     indent=2))


if __name__ == '__main__':
    main()
