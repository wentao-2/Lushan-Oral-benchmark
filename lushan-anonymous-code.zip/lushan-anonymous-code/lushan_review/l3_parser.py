"""Fixed answer parser for L3 jobs. Returns the chosen option number (1..n) or None (invalid).

Rules, applied in order; the first rule that yields a value decides:
 1. Drop <think>...</think> blocks, markdown emphasis and surrounding whitespace.
 2. The whole reply is one option number, optionally wrapped or followed by punctuation: "2", "(2)", "2.", "【2】".
 3. An explicit answer phrase followed by a number: "Answer: 2", "The answer is option 2", "答案：2", "选 2".
 4. The reply starts with a number and a separator, then text: "2. No obvious rotation", "2 - ...", "2：...".
    If option text follows and it names a different option, the reply is invalid.
 5. Exactly one option label (case-insensitive) occurs in the reply, after discarding labels that are
    substrings of another occurring label.
 6. Exactly one distinct standalone number in 1..n occurs, no option label occurs, and every other
    number in the reply is a valid FDI tooth number (11-48).
Anything else is invalid. Numbers outside 1..n are invalid. Tooth numbers such as 13 are never read as
options because a digit must not touch another digit.
"""
import re

_THINK = re.compile(r'<think>.*?</think>', re.S | re.I)
_WRAP = r'[\s\(\[（【「"\'“]*'
_TAIL = r'[\s\)\]）】」"\'”\.。:：,，;；!！]*'
_ANSWER = re.compile(r'(?:final\s+answer|answer|option|choice|答案|选项|选择|应选|选)\s*(?:is|为|是|:|：)?\s*'
                     r'(?:option|选项|第)?\s*[\(\[（【]?\s*(\d+)(?!\d)', re.I)
_LEAD = re.compile(r'^[\(\[（【]?\s*(\d+)(?!\d)\s*[\)\]）】]?\s*[\.。:：、\-–—)]\s*(.*)$', re.S)
_NUM = re.compile(r'(?<![\d.])(\d+)(?![\d])')


def _clean(text):
    t = _THINK.sub(' ', text or '')
    t = t.replace('**', '').replace('__', '').replace('`', '')
    return t.strip()


def _labels_in(text, labels):
    low = text.lower()
    hit = [i for i, lab in enumerate(labels) if lab.lower() in low]
    return [i for i in hit if not any(j != i and labels[i].lower() in labels[j].lower() for j in hit)]


def parse(text, labels):
    """labels: option texts in the order presented (number = index + 1)."""
    n = len(labels)
    t = _clean(text)
    if not t:
        return None
    m = re.fullmatch(_WRAP + r'(\d+)' + _TAIL, t)
    if m:
        v = int(m.group(1))
        return v if 1 <= v <= n else None
    m = _ANSWER.search(t)
    if m:
        v = int(m.group(1))
        return v if 1 <= v <= n else None
    m = _LEAD.match(t)
    if m:
        v = int(m.group(1))
        if not 1 <= v <= n:
            return None
        named = _labels_in(m.group(2), labels)
        if named and named != [v - 1]:
            return None
        return v
    named = _labels_in(t, labels)
    if len(named) == 1:
        return named[0] + 1
    if named:
        return None
    nums = {int(x) for x in _NUM.findall(t)}
    valid = {v for v in nums if 1 <= v <= n}
    others = nums - valid
    if len(valid) == 1 and all(_FDI(v) for v in others):
        return valid.pop()
    return None


def _FDI(v):
    return 11 <= v <= 48 and 1 <= v % 10 <= 8 and v // 10 in (1, 2, 3, 4)
