"""Compact, anonymized benchmark code for review."""
