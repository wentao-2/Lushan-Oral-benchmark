"""CPU scoring kernel for the frozen four-task protocol."""
import math

from .l2_parser import parse_response


def score_answer(text, task, truth, instance_mask=None):
    parsed = parse_response(text, task)
    point = parsed["pixel_xy"]
    marker = task == "marker"
    visible = True if marker else truth["localization_answerable"]
    hit = False
    if task != "fdi":
        if instance_mask is None or instance_mask.shape != (512, 512):
            raise ValueError("expected_original_512_pixel_instance_mask")
        if parsed["point_extractable"] and point is not None and visible:
            x, y = map(math.floor, point)
            hit = int(instance_mask[y, x]) == truth["instance_id"]
    rejection = parsed["point_extractable"] and point is None and not visible
    correct_fdi = parsed["fdi"] == truth["truth_fdi"]
    row = {
        "visible": visible,
        "fdi_extractable": parsed["fdi_extractable"],
        "point_extractable": parsed["point_extractable"],
        "fdi_correct": correct_fdi,
        "localization_correct": hit or rejection,
        "joint_correct": correct_fdi and (hit or rejection),
        "visible_hit": hit,
        "absent_rejection": rejection,
        "parsed_fdi": parsed["fdi"],
        "parsed_pixel_xy": point,
        "point_extraction": parsed["point_extraction"],
    }
    if marker:
        distance = math.dist(point, truth["source_pixel_xy"]) if point is not None else None
        row["marker_distance"] = distance
        row["marker_within_7px"] = distance is not None and distance <= 7
    return row
