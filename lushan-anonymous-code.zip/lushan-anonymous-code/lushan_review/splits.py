"""Case and duplicate-geometry grouping before split assignment."""
from __future__ import annotations
import collections
import hashlib
SPLITS = ('train', 'val', 'test')

def grouped_splits(rows: list[dict], anchors: list[dict]) -> tuple[dict, dict]:
    """Union case IDs and exact geometry IDs, then inherit or hash whole groups.

    Conflicting landmark anchors are quarantined in this new snapshot instead
    of silently rewriting established train/validation/test memberships.
    """
    parent: dict[str, str] = {}

    def find(x):
        parent.setdefault(x, x)
        if parent[x] != x:
            parent[x] = find(parent[x])
        return parent[x]

    def union(a, b):
        a, b = find(a), find(b)
        if a != b:
            parent[max(a, b)] = min(a, b)

    for row in rows:
        case = 'case:'+row['case_id']
        find(case)
        for key in ('original_stl_sha256', 'mesh_key'):
            if row.get(key):
                union(case, key+':'+row[key])
    anchor_by_case = collections.defaultdict(set)
    for row in anchors:
        if row['split'] not in SPLITS:
            raise ValueError('Unexpected inherited landmark split')
        anchor_by_case[row['case_id']].add(row['split'])
    groups = collections.defaultdict(set)
    for row in rows:
        groups[find('case:'+row['case_id'])].add(row['case_id'])
    assignments, conflict_groups = {}, []
    inherited = hashed = 0
    for cases in sorted(groups.values(), key=lambda c: min(c)):
        required = set().union(*(anchor_by_case[c] for c in cases))
        if len(required) > 1:
            split = 'quarantine'
            conflict_groups.append({'case_ids': sorted(cases), 'anchor_splits': sorted(required)})
        elif required:
            split = next(iter(required))
            inherited += 1
        else:
            # Anchor-free exact-geometry groups use their minimum anonymous case
            # ID, producing stable assignment as reviews become available.
            score = int(hashlib.sha256(('oral-jaws-multitask-v1:'+min(cases)).encode()).hexdigest(), 16) / 2**256
            split = 'train' if score < .7 else 'val' if score < .8 else 'test'
            hashed += 1
        assignments.update({case: split for case in cases})
    report = {'grouping': ['case_id', 'original_stl_sha256', 'mesh_key'],
              'inherited_component_count': inherited, 'hashed_component_count': hashed,
              'quarantined_components': conflict_groups,
              'case_id_is_verified_patient_id': False,
              'new_group_policy': 'sha256 oral-jaws-multitask-v1:min_case_id, thresholds 0.7 / 0.8',
              'existing_landmark_splits_modified': False}
    return assignments, report
