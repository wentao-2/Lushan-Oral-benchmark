# Level 3 inference-time prompt workflows

The excerpts below reproduce the frozen message-construction functions. They document message order, prompt additions, visual transformations and follow-up calls. They are protocol excerpts, not standalone inference programs. The original query prompts are in `l3_mcq_prompts.json` and `l3_open_prompts.json`.

## Multiple-choice methods

Source SHA-256: `0a6efa052c4e68eb6f2c091ba3b525e26e63aebadf37f6dd89f2896c9cfe6156`.

```python
def message(prompt,labels):
    c=[]
    for label in labels:c.extend([{'type':'text','text':label},{'type':'image'}])
    c.append({'type':'text','text':prompt});return {'role':'user','content':c}
```

```python
def execute(self,job,method):
        from PIL import Image,ImageDraw
        original=self.images(job['images']);labels=job['image_labels'];zh=job['lang']=='zh'
        system={'role':'system','content':[{'type':'text','text':CONFIG['system_prompt']}]}
        base=[system,message(job['prompt'],labels)];calls=[];actions=[]
        def invoke(msgs,ims):
            r,path=self.call(msgs,ims);calls.append({'path':path,'sha256':sha(ROOT/path)});return r['raw_response']
        if method=='icl2':
            eligible=[d for d in self.demos[job['kind']] if d['source_case_id']!=job['source_case_id']]
            first=eligible[0];second=next(d for d in eligible[1:] if d['source_case_id']!=first['source_case_id'] and d['answer_code']!=first['answer_code'])
            msgs=[system];images=[]
            for d in [first,second]:
                dj=d[job['lang']];dl=dj['image_labels'] if original else []
                msgs.extend([message(dj['prompt'],dl),{'role':'assistant','content':str(d['answer_number'])}])
                if original:images.extend(self.images(dj['images']))
            msgs.append(base[-1]);images.extend(original)
            result=invoke(msgs,images);actions=[{'tool':'two_training_examples','qids':[first['qid'],second['qid']],
                       'cases':[first['source_case_id'],second['source_case_id']],'demonstration_images_omitted':not bool(original)}]
        elif method=='grid':
            images=[]
            for im in original:
                overlay=Image.new('RGBA',im.size,(0,0,0,0));d=ImageDraw.Draw(overlay)
                for xy in (128,256,384):
                    d.line((xy,0,xy,511),fill=(0,110,255,105),width=1);d.line((0,xy,511,xy),fill=(0,110,255,105),width=1)
                for r in range(4):
                    for c in range(4):d.text((c*128+3,r*128+3),chr(65+r)+str(c+1),fill=(0,60,220,220))
                images.append(Image.alpha_composite(im.convert('RGBA'),overlay).convert('RGB'))
            extra=('蓝色4×4网格仅用于比较位置；各图网格独立，不表示同一三维位置，网格不代表牙齿。仍只回答原选项编号，不要解释。' if zh else
                   'A blue 4 by 4 grid aids visual comparison. Grids are independent image coordinates, not 3D correspondences or tooth boundaries. Answer only the original option number, without explanation.')
            result=invoke([system,message(job['prompt']+('\n\n'+extra if images else ''),labels)],images)
            actions=[{'tool':'uniform_grid','rows':4,'columns':4,'applied':bool(images),'geometry_changed':False}]
        elif method=='observe_then_answer':
            instruction=('先描述题目指定范围内可见的牙冠形态、相邻接触及局部牙弓走向。不选择答案，不补充图像以外的信息，最多80字。' if zh else
                         'First describe the visible crown alignment, adjacent contacts and local arch direction relevant to the specified scope. Do not choose an option or invent unseen findings. Use at most 60 words.')
            observation=invoke([system,message(job['prompt']+'\n\n'+instruction,labels)],original)
            follow=('以上观察是模型自己的推测，可能有误。重新检查原图并回答原题；只回答选项编号，不要解释。' if zh else
                    'The observations above are model predictions and may be wrong. Recheck the original images and answer the original question. Return the option number only, without any explanation.')
            result=invoke(base+[{'role':'assistant','content':observation},{'role':'user','content':follow}],original)
            actions=[{'tool':'observe_then_answer','adapted_from_l2':'decomposed FDI/localization; L3 target FDI is already given'}]
        elif method in ('self_review','crop_zoom'):
            b,source=baseline(self.model_name,self.stage,job);first=b['raw_response'];actions=[{'tool':'reused_direct_answer','source':source}]
            if method=='self_review':
                follow=('对照原图和题目指定范围检查一次答案，特别注意患者左右侧、牙冠与局部牙弓、间隙与牙龈三角空隙的区别，以及证据是否足够。只回答最终选项编号，不要解释。' if zh else
                        'Check the answer once against the original images and specified scope: patient side, crown alignment relative to the local arch, interdental versus gingival space, and sufficiency of evidence. Return only the final option number, without explanation.')
                result=invoke(base+[{'role':'assistant','content':first},{'role':'user','content':follow}],original)
            else:
                images=list(original);newlabels=list(labels)
                meta=self.items[job['qid']]
                if original:
                    pts=[m['xy'] for m in meta['markers']]
                    if pts:
                        xs,ys=zip(*pts);side=min(512,max(256,int(max(max(xs)-min(xs),max(ys)-min(ys))+128)))
                        cx,cy=(min(xs)+max(xs))/2,(min(ys)+max(ys))/2
                    else:side=384;cx=cy=256
                    left=min(max(round(cx-side/2),0),512-side);top=min(max(round(cy-side/2),0),512-side);box=[left,top,left+side,top+side]
                    images.append(original[0].crop(box).resize((512,512),Image.Resampling.BICUBIC))
                    newlabels.append(('公开全图裁剪放大：' if zh else 'Additional crop enlarged from original Image 1:')+str(box))
                    actions.append({'tool':'crop_from_public_markers','source_image_index':0,'box_original_pixels':box,'resample':'BICUBIC','metadata_source':'public items.json'})
                extra=('最后一张附加图只由原全图裁剪放大，没有新视角或新证据。结合完整原图重新检查，不能只靠局部推断整个牙弓。' if zh else
                       'The extra close-up is only a crop of the original whole image, not a new view or new evidence. Recheck with all original images; do not infer the whole arch from the crop alone.') if original else ''
                follow=('先前的模型答案为 '+first+'。'+extra+'只回答最终选项编号，不要解释。' if zh else
                        'The preceding model answer was '+first+'. '+extra+' Return only the final option number, without explanation.')
                result=invoke([system,message(job['prompt']+'\n\n'+follow,newlabels)],images)
        else:raise ValueError(method)
        return result,calls,actions
```

Training demonstration texts are in `l3_mcq_demonstrations.json`; image files and source-case identifiers are omitted.

## Open-answer methods

Source SHA-256: `d3bb92a59fe7e43f392c8eba641ce72da07a4b109dfed2912a549fb74af4edd2`.

```python
def message(prompt, labels):
    content = []
    for label in labels:
        content.extend([{'type': 'text', 'text': label}, {'type': 'image'}])
    content.append({'type': 'text', 'text': prompt})
    return {'role': 'user', 'content': content}
```

```python
def execute(self, job, method):
        from PIL import Image, ImageDraw
        original = self.images(job['images'])
        labels = job['image_labels']
        system = {'role': 'system', 'content': [{'type': 'text', 'text': CONFIG['system_prompt']}]}
        base = [system, message(job['prompt'], labels)]
        calls, actions = [], []

        def invoke(messages, images):
            record, path = self.call(messages, images)
            calls.append({'path': path, 'sha256': sha(ROOT / path)})
            return record['raw_response']

        if method == 'direct':
            answer = invoke(base, original)
        elif method == 'icl2':
            eligible = [d for d in self.demos if d['source_case_id'] != job['source_case_id']]
            same_jaw = [d for d in eligible if d['jaw'] == self.job_meta[job['qid']]['jaw']]
            eligible = same_jaw if len(same_jaw) >= 2 else eligible
            examples = eligible[:2]
            require(len({d['source_case_id'] for d in examples}) == 2, 'two distinct training cases')
            messages, images = [system], []
            for d in examples:
                require(d['split'] == 'train', 'ICL source split')
                messages.extend([message(d['prompt'], d['image_labels']),
                                 {'role': 'assistant', 'content': d['reference']}])
                images.extend(self.images(d['images']))
            messages.append(base[-1]); images.extend(original)
            answer = invoke(messages, images)
            actions.append({'tool': 'two_training_examples', 'qids': [d['qid'] for d in examples],
                            'cases': [d['source_case_id'] for d in examples], 'source_split': 'train'})
        elif method == 'grid':
            images = []
            for im in original:
                overlay = Image.new('RGBA', im.size, (0, 0, 0, 0)); draw = ImageDraw.Draw(overlay)
                for xy in (128, 256, 384):
                    draw.line((xy, 0, xy, 511), fill=(0, 110, 255, 105), width=1)
                    draw.line((0, xy, 511, xy), fill=(0, 110, 255, 105), width=1)
                for r in range(4):
                    for c in range(4):
                        draw.text((c*128+3, r*128+3), chr(65+r)+str(c+1), fill=(0, 60, 220, 220))
                images.append(Image.alpha_composite(im.convert('RGBA'), overlay).convert('RGB'))
            extra = ('A blue 4 by 4 grid aids location descriptions. Each image has independent image coordinates; '
                     'grid cells are not tooth boundaries or 3D correspondences. Answer the original open question '
                     'and identify the teeth or locations involved. Grid references are optional.')
            answer = invoke([system, message(job['prompt']+'\n\n'+extra, labels)], images)
            actions.append({'tool': 'uniform_grid', 'rows': 4, 'columns': 4, 'geometry_changed': False})
        elif method == 'observe_then_answer':
            extra = ('First describe the visible crown alignment, adjacent contacts and local arch direction '
                     'within the specified region. Do not give the final assessment yet. Do not invent unseen '
                     'findings. Keep these preliminary observations within 60 words.')
            observation = invoke([system, message(job['prompt']+'\n\n'+extra, labels)], original)
            follow = ('These preliminary observations are model predictions and may be wrong. Recheck the original '
                      'images, then answer the original open question in full. Describe the main alignment '
                      'problems and the teeth or locations involved; state uncertainty where necessary.')
            answer = invoke(base+[{'role': 'assistant', 'content': observation},
                                  {'role': 'user', 'content': follow}], original)
            actions.append({'tool': 'observe_then_answer', 'calls': 2})
        elif method in ('crop_zoom', 'self_review'):
            first, source = baseline(self.model_name, self.stage, job)
            actions.append({'tool': 'reused_direct_answer', 'source': source})
            if method == 'self_review':
                follow = ('Check your answer against the original images and specified region. Check patient side, '
                          'tooth positions relative to the local arch, interdental versus gingival spaces, and '
                          'whether the image supports each claim. Correct errors or unsupported claims, then '
                          'provide the complete final answer to the original open question.')
                answer = invoke(base+[{'role': 'assistant', 'content': first['raw_response']},
                                      {'role': 'user', 'content': follow}], original)
            else:
                # Fixed image-coordinate rule, no test references, tooth boxes, or markers.
                box = [64, 64, 448, 448]
                images = original + [original[0].crop(box).resize((512, 512), Image.Resampling.BICUBIC)]
                newlabels = labels + ['Additional center crop from Image 1, original pixel box [64,64,448,448]:']
                extra = ('The extra close-up is a fixed center crop of the original whole image, not a new view '
                         'or new clinical evidence. Recheck with all original images; do not infer the whole '
                         'arch from the crop alone. Your preceding answer was:\n'+first['raw_response']+
                         '\n\nProvide the complete final answer to the original open question, correcting '
                         'unsupported claims and indicating uncertainty where necessary.')
                answer = invoke([system, message(job['prompt']+'\n\n'+extra, newlabels)], images)
                actions.append({'tool': 'fixed_center_crop', 'box_original_pixels': box,
                                'resample': 'BICUBIC', 'source_image_index': 0, 'uses_private_locations': False})
        else:
            raise ValueError(method)
        return answer, calls, actions
```

Training demonstration texts are in `l3_open_demonstrations.json`; image files and source-case identifiers are omitted.
