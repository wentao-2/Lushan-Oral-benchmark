# Judging rubric v2: open answers to L3 dental questions

You read a model's free-text answer about a dental arch and record what it says about a fixed list of **targets**.
You do not see the image, the correct answers, or which model wrote the answer. Do not guess what is true. Only record what the answer states.

v2 is v1 with the ambiguities from the pilot resolved. The changed rules are marked **(v2)**.

## Input

Each item has:
- `orientation` and `question`, exactly as the model saw them.
- `targets`, each with a `target_id`, a `concept` and a `subject`:
  - `regional_crowding`: crowding of a region, such as "the lower anterior region (43 to 33)".
  - `whole_crowding`: crowding of a whole dentition.
  - `rotation`: rotation of one tooth, such as tooth 32.
  - `displacement`: inward (lingual or palatal) or outward (labial or buccal) displacement of one tooth.
  - `spacing`: a definite interdental gap between two teeth, such as 32 and 33.
- `answers`, each with an `answer_id` and its `text`.

## Output

For every answer and every target, give one `stance`, a `direction` and an `evidence` list.

Evidence is one or two short fragments (at most about 20 words each), copied exactly character for character from the answer. Do not paraphrase. If the stance is `not_mentioned`, the evidence list is empty.

Also list the answer's `extra_claims`.

### Stance values

For `regional_crowding`, `whole_crowding`, `rotation` and `spacing`:

| stance | use when the answer… |
|---|---|
| `present` | asserts the problem for this subject without downgrading it. "Obvious", "marked", "significant", "moderate" or no qualifier all count. |
| `mild` | asserts it but calls it slight, mild, minor or minimal. |
| `uncertain` | says it may be present, offers it only as one of several alternatives, or says it cannot be determined for this subject. |
| `absent` | states that this subject does not have the problem. Region-wide normal statements count. |
| `contradictory` | says both present and absent for the same subject. |
| `not_mentioned` | says nothing that applies to this subject and concept. |

For `displacement`, use the same values, but replace `present` with one of these:
- `labial`: outward, toward the lips or cheeks. Includes labially or buccally placed, flared, proclined or protruding forward.
- `lingual`: inward, toward the tongue or palate. Includes lingually or palatally placed, retroclined, set back or behind the arch.
- `displaced_unspecified`: the answer says the named tooth is displaced, malpositioned, out of the arch or out of line with the arch, but gives no inward or outward direction.

The `direction` field is `labial`, `lingual` or `null`. `mild` and `uncertain` may still carry a direction.

## How to map the answer to a target

1. **Teeth.** Anatomical names map to FDI numbers:
   - quadrants: upper right = 1x, upper left = 2x, lower left = 3x, lower right = 4x;
   - tooth types: central incisor = x1, lateral incisor = x2, canine = x3, first premolar = x4, second premolar = x5.

   If the answer gives an FDI number together with a name that does not match it, such as "lower left canine (43)", use the FDI number. The patient's left is image right. Use an image-relative description only when it identifies the tooth unambiguously.
2. **(v2) A finding must name the tooth.** A positive rotation, displacement or spacing statement counts for a target only when the answer names that tooth, or a named group that contains it. Examples of named groups: "the four incisors", "both lateral incisors", "the canines", "all six anterior teeth".
   - Statements about "the teeth", "some teeth", "several teeth" or the region in general do not count for any tooth target. This includes causal remarks such as "crowding pushes the teeth forward". Record them as extra claims with the region as subject.
   - Normal statements are different. A region-wide normal statement, such as "the anterior teeth are well aligned", "no rotations" or "no gaps", gives `absent` for every target inside that region. This does not apply if the answer makes a specific statement about that target elsewhere. Then use the specific statement, or `contradictory` if the two conflict for the same tooth and concept.
3. **(v2) Generic alignment words do not name a problem.** Words like "misaligned", "irregular", "not properly aligned", "malaligned" or "not in a smooth arch" add nothing on their own:
   - for rotation, displacement and spacing targets they are `not_mentioned`;
   - for crowding targets they count only together with crowding words: crowded, overlapping, insufficient space, jumbled, squeezed.
4. **Concepts.**
   - Rotation means the tooth is turned about its long axis: rotated, twisted, turned, mesio- or disto-rotated.
   - Crowding means overlapping, squeezed or insufficient space. Crowding of named teeth inside the region, such as "the incisors are crowded", counts for the region's crowding target. Crowding of the whole dentition counts for the anterior target only if the answer places it in the anterior teeth or calls it generalized.
   - **(v2)** These are not inward or outward displacement, and not rotation: sideways shifts (mesial, distal, to the left or right, toward the midline), midline shifts, tilting or tipping, extrusion or intrusion, crossbite, overbite and overjet. Record them as extra claims with concept `other`. One exception: protruding, flared or proclined incisors count as `labial`.
5. **(v2) Spacing pairs.** A gap statement counts for a pair when any of these hold:
   - the answer names both teeth;
   - it names one tooth and puts the gap on the side of the other, e.g. "a gap between 12 and the central incisor" covers 11–12;
   - it says there are gaps on both sides of a tooth, which covers both neighbours.

   "Uneven spacing" or "spacing in the region" with no pair does not count. "Tightly packed", "no gaps" or "teeth in contact" in a region gives `absent` for every pair in that region.
6. **Hedges.** "Appears", "seems" or "likely" with no other doubt keep the stated stance. These mean `uncertain`:
   - "possibly", "may", "might", "cannot rule out", "suspected" or "hard to tell";
   - **(v2)** a finding offered only as one of several alternatives, such as "rotated or displaced".
7. **(v2) Comparisons.** "In a more normal position" or "relatively well aligned" give `absent` for that tooth and concept, unless the answer also asserts a problem there.
8. Measurements and causes, such as degrees, millimetres or reasons, do not change the stance. Statements about the image itself, such as "the image is blurry", are not a stance unless they say this specific subject cannot be assessed. Then use `uncertain`.

## Extra claims

List each abnormality the answer asserts, without hedging, that does not map to any target. Include:
- problems on other teeth;
- other concepts on target teeth;
- unlocalized findings;
- missing teeth and other findings.

Each extra claim gets a `subject` (FDI number(s) or region) and a `concept`: crowding, rotation, displacement, spacing, missing_tooth or other. Normal statements are not extra claims.

Answers may be in any language. Copy evidence in the answer's own language.

## Output format

Write one JSON array, with one object per item in batch order:

```json
[{"item_id": "...", "answers": [
  {"answer_id": "...", "targets": [
     {"target_id": "F1", "stance": "present", "direction": null, "evidence": ["the lower incisors are crowded"]},
     {"target_id": "F2", "stance": "not_mentioned", "direction": null, "evidence": []}],
   "extra_claims": [{"subject": "31", "concept": "rotation"}]}]}]
```

Judge every answer on its own text.
