# Supplementary data and protocol files

This directory accompanies the supplementary PDF and is also included in the
anonymous code package. Paths cited in the PDF are relative to the package root.
It contains protocol text and aggregate results; patient scans and images are not
included. Source case identifiers and private filesystem paths are omitted.

| File | Content |
|---|---|
| `l1_training_settings.json` | Archived segmentation/FDI configurations for six main baseline models, both training regimes and seeds 0/1/2; six landmark detectors at three seeds; PTv3, TCATSeg and Utonia at seed 0. Includes sampling, optimizer, learning rate, training budget and checkpoint selection as recorded in each configuration. Local paths are reduced to file names. |
| `l2_removal_pairs.csv` | All 33 L2 configurations from former Table A5, including zero results, under independent and fixed framing. Scores are percentages. |
| `recent_l1_scan_accuracy.csv` | All 48 recent-baseline model/training/condition combinations. `scan_accuracy` follows the main-text reference-tooth definition. `strict_scan_accuracy` additionally excludes extra predictions. Counts, differences in percentage points, unchanged tooth accuracy and joint F1 are provided. |
| `l3_mcq_prompts.json` | Exact frozen multiple-choice prompts, option codes, image order labels, splits and control conditions. Contains the development/test job files and Chinese-language controls. Query IDs identify questions, not patients. |
| `l3_open_prompts.json` | Exact frozen direct open-question prompts and full/crop image labels. Includes development and formal jobs; use each job's split and run fields to select the required subset. |
| `l3_prompt_methods.md` | Frozen message-construction excerpts for the five inference-time methods, including prompt additions, image transformations and follow-up calls. These are protocol excerpts, not standalone inference programs. |
| `l3_mcq_demonstrations.json`, `l3_open_demonstrations.json` | Training demonstration prompt/reference text used by ICL, with source-case linkage and image files omitted. The workflow specifies selection and ordering. |
| `l3_generation_settings.json` | Recorded system messages, generation settings, model revisions and input-processing descriptions for the local MCQ/open-answer runs and method runs. |
| `l3_judge_rubric.md` | Full archived v2 answer-stance extraction rubric. The extractor is blinded to reference states, model names and images. Final credit is assigned using the supplementary PDF's scoring rules. |
| `qwen9b_image_diagnostic.json` | Separate image-input checks and a historical-input audit for Qwen3.5-9B. These diagnostics do not replace or change benchmark predictions. |
| `recent_l1_rescore_validation.json` | Source checksums and validation of the CPU reaggregation of Scan Acc.; original predictions, geometric matching and all count-based tooth/segmentation scores are unchanged. |
| `protocol_files_manifest.json` | SHA-256 checksums of the accompanying protocol and aggregate-result files. |

## Scan Acc. convention

For each scan, Scan Acc. is one exactly when **every scored reference tooth** is
correctly matched and numbered. Average this flag equally over scans. Extra
predicted instances reduce joint F1; they do not change this flag. Strict Scan
Acc. also requires no extra instances and is reported only as a separate
diagnostic. The CSV preserves both definitions and the scan counts.

The CPU audit reproduced the former strict scores and the unchanged tooth and
joint counts before reaggregating the main-text flag. For an additional check,
the same reference-tooth rule reproduces the main table's 70.24% three-seed
PointNet++ MSG score under augmented training on original test scans.

## Retained numbering

The PDF retains the submitted cross-reference identifiers. Former Tables A5,
A10, A11 and A13 are expressed in prose; these numbers remain reserved. The
complete former A5 rows are in `l2_removal_pairs.csv`. Figure A5 retains its
identifier, with the open-answer panel now at panel (i). Tables in the source
project use numerical source files and presentation-only variants separately.
