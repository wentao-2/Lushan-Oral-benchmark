"""Behavioral checks using fabricated arrays, never patient geometry."""
import tempfile
import unittest
from pathlib import Path
import numpy as np
from lushan_review import splits, missing_teeth as mt, l1_scoring as l1
from lushan_review import projection, l2_parser, l2_scoring, l3_parser


class CoreTests(unittest.TestCase):
    def test_split_duplicates_and_conflicts(self):
        rows = [{'case_id': 'synthetic-a', 'mesh_key': 'shared'},
                {'case_id': 'synthetic-b', 'mesh_key': 'shared'}]
        result, _ = splits.grouped_splits(rows, [{'case_id': 'synthetic-a', 'split': 'test'}])
        self.assertEqual(set(result.values()), {'test'})
        result, report = splits.grouped_splits(rows, [{'case_id': 'synthetic-a', 'split': 'test'},
                                                    {'case_id': 'synthetic-b', 'split': 'train'}])
        self.assertEqual(set(result.values()), {'quarantine'})
        self.assertEqual(len(report['quarantined_components']), 1)

    def test_internal_removal_and_face_order(self):
        candidates = mt.deletion_candidates(mt.arch_slots('upper'), 'upper')
        self.assertIn([11, 21], candidates['adjacent_pair'])
        self.assertNotIn([18], candidates['single_internal'])
        self.assertFalse(any(mt.deletion_candidates([15,14,13,12,11,21], 'upper').values()))
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)/'synthetic.npz'
            np.savez(p, face_instance=np.array([0, 2, 1, 2, 1]))
            keep = np.array([0, 2, 4], dtype=np.int64)
            row = {'scan_id': 'synthetic', 'label_npz': str(p), 'conditions': {'single_internal': {
                'available': True, 'delete_instance_ids': [2], 'remaining_face_count': 3,
                'kept_original_face_ids_sha256': mt.index_sha256(keep)}}}
            np.testing.assert_array_equal(mt.kept_original_face_ids(row, 'single_internal'), keep)
            row['conditions']['single_internal']['kept_original_face_ids_sha256'] = 'wrong'
            with self.assertRaises(RuntimeError): mt.kept_original_face_ids(row, 'single_internal')

    def test_training_variant_never_uses_test(self):
        with self.assertRaises(ValueError):
            mt.select_training_variant({'split': 'test'}, 0, 0)
        conditions = {'original': {'available': True, 'delete_instance_ids': [], 'delete_fdi': []}}
        for key in mt.TRAIN_TYPES:
            conditions[key] = {'available': False, 'unavailable_reason': 'synthetic-unavailable'}
        row = {'split': 'train', 'scan_id': 'synthetic', 'conditions': conditions}
        for epoch in range(20):
            self.assertEqual(mt.select_training_variant(row, 0, epoch)['condition'], 'original')

    def test_l1_extra_prediction_and_wrong_number(self):
        gt = np.array([0,0,1,1,2,2]);ids = np.array([1,2]);fdi = np.array([11,21])
        def score(pred, pids, pfdi):
            return l1.score(gt, ids, fdi, np.zeros(2, bool), np.ones(6, bool),
                            {'face_instance': np.array(pred), 'instance_ids': np.array(pids), 'instance_fdi': np.array(pfdi)})
        perfect = score(gt, ids, fdi)
        self.assertTrue(perfect['joint']['exact_scan_correct'])
        extra = score([3,3,1,1,2,2], [1,2,3], [11,21,12])
        self.assertEqual(extra['accuracy'], 1)
        self.assertFalse(extra['joint']['exact_scan_correct'])
        self.assertLess(extra['joint']['f1'], 1)
        swapped = score(gt, ids, [21,11])
        self.assertEqual(swapped['instance_segmentation']['f1'], 1)
        self.assertEqual(swapped['accuracy'], 0)

    def test_projection_and_inside_point(self):
        v=np.array([[-1.,-1,0],[1,-1,0],[1,1,0],[-1,1,0]])
        s,m=projection.projected(v,np.zeros(3),np.eye(3),projection.rotation(0,0,0),projection.frame('synthetic','target'))
        np.testing.assert_allclose(np.c_[v,np.ones(len(v))]@m.T, np.c_[s,np.ones(len(s))])
        mask=np.zeros((512,512),np.int32);mask[240:272,240:272]=2
        point,distance,area=projection.interior(mask,2)
        self.assertEqual(mask[point[1],point[0]],2);self.assertEqual(area,1024)
        self.assertGreater(distance,0)

    def test_l2_coordinates_null_and_invalid(self):
        mask=np.zeros((512,512),np.int32);mask[256,256]=2
        truth={'truth_fdi':21,'instance_id':2,'localization_answerable':True}
        row=l2_scoring.score_answer('{"fdi":21,"pixel_xy":[500,500]}','joint',truth,mask)
        self.assertTrue(row['joint_correct'])
        row=l2_scoring.score_answer('{"fdi":21,"pixel_xy":null}','joint',truth,mask)
        self.assertFalse(row['joint_correct'])
        truth['localization_answerable']=False
        self.assertTrue(l2_scoring.score_answer('{"fdi":21,"pixel_xy":null}','joint',truth,mask)['absent_rejection'])
        self.assertFalse(l2_scoring.score_answer('', 'joint', truth, mask)['absent_rejection'])
        for text in ['{"pixel_xy":[1000,500]}','{"pixel_xy":[-1,500]}','{"pixel_xy":[NaN,500]}']:
            self.assertFalse(l2_parser.parse_response(text,'localization')['point_extractable'])

    def test_l3_tooth_number_is_not_option(self):
        labels=['Rotation present','No obvious rotation','Cannot assess']
        self.assertEqual(l3_parser.parse('Answer: 2',labels),2)
        self.assertIsNone(l3_parser.parse('21',labels))
        self.assertIsNone(l3_parser.parse('',labels))
        self.assertIsNone(l3_parser.parse('2. Rotation present',labels))


if __name__ == '__main__':
    unittest.main()
