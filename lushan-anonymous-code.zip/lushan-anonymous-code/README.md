# Lushan: anonymous review code and protocol files

This package provides selected data-processing and scoring functions, synthetic
software examples, model-facing protocol text, and aggregate benchmark results.
It includes no patient scans/images, source-case linkage, model weights,
credentials, machine addresses, or Git history.

## Quick start

Use Python 3.10 or later from this directory:

```bash
python -m pip install -r requirements.txt
python -m lushan_review.demo
python -m unittest discover -s tests -v
```

The demo and tests run on CPU with fabricated arrays. They are software checks,
not benchmark results. `requirements.txt` lists the runtime dependencies.

## Included components

| Module | Purpose |
|---|---|
| `splits.py` | Group cases and identical geometry; quarantine conflicting inherited splits. |
| `missing_teeth.py` | Select removals and training variants while preserving original face indices and FDI labels. |
| `projection.py` | Apply camera rotations and framing, return projection matrices and interior target points. |
| `l1_scoring.py` | Match instances by geometry at IoU 0.5, then score segmentation and FDI recognition. |
| `rescore_scan_accuracy.py` | Reaggregate saved per-scan matches using the main-text Scan Acc. rule; retain the strict diagnostic. |
| `l2_parser.py`, `l2_scoring.py` | Parse identity/coordinates/null and score against original 512 x 512 masks. |
| `l3_parser.py` | Parse multiple-choice option numbers without mistaking tooth numbers for options. |

`PROVENANCE.json` records source checksums and adaptation scope.
`docs/PROTOCOL_NOTES.md` explains the scoring conventions.

**Scan Acc.** uses `joint.scan_correct`: every scored reference tooth is correctly
matched and numbered. `joint.strict_scan_correct` additionally requires no extra
predictions. The legacy `joint.exact_scan_correct` remains an alias for the strict
flag. Extra predictions are penalized by joint F1 under both reporting conventions.

## Supplementary protocol and result files

See `supplement_data/README.md` for the file index. It includes archived L1 training
settings, exact L3 query prompts and method workflows, ICL demonstration text,
the answer-extraction rubric, complete L2 removal-pair results, corrected recent
L1 Scan Acc. values and separate Qwen3.5-9B input diagnostics. Source checksums
are retained, while patient images and source-case identifiers are omitted.

This is a selected core-code release. Full mesh rendering, training orchestration,
landmark evaluation, model-specific inference adapters, and the complete
open-answer judging pipeline are outside the package. Reproducing full benchmark
tables additionally requires the frozen data, checkpoints and corresponding runs.

## Data, annotators, and ethics

The de-identified raw STL scans and detailed professional qualifications of the
annotation personnel will be released with the final publication. The manuscript
describes two orthodontists with more than eight years of clinical experience
and five orthodontic master's students. Identifying affiliations and the ethics
approval identifier are deferred to the final version for double-blind review.
The manuscript reports ethics approval and informed consent.

## License and upload

Code is provided under the accompanying MIT license. This code license does not
grant access or redistribution rights to unreleased clinical data.
Upload the contents of this directory to the anonymous repository. The archive
contains no `.git` directory or commit metadata.
