# Lushan: anonymous review code

This compact package exposes selected data-processing and evaluation functions
used in our benchmark. It runs locally on CPU and contains **synthetic examples
only**. It does not contain patient scans, clinical records, annotation accounts,
model weights, API credentials, machine addresses, or experiment logs.

## Quick start

Use Python 3.10 or later, from this directory:

```bash
python -m pip install -r requirements.txt
python -m lushan_review.demo
python -m unittest discover -s tests -v
```

The demo prints results for synthetic face labels, a synthetic target mask,
and fabricated case identifiers. These are software checks, not benchmark scores.
No GPU, account, clinical data, or network inference is required.

## Included components

| Module | Purpose |
|---|---|
| `splits.py` | Group cases and identical geometry before assigning splits; quarantine conflicting inherited splits. |
| `missing_teeth.py` | Select internal tooth removals and training variants; retain original mesh-face indices and FDI labels. |
| `projection.py` | Apply camera rotations and framing, return the projection matrix, and choose an interior target point. |
| `l1_scoring.py` | Match instances by geometry at IoU 0.5, then evaluate segmentation and FDI recognition. |
| `l2_parser.py`, `l2_scoring.py` | Parse FDI/coordinates/null and test points against the original 512 x 512 target-instance mask. |
| `l3_parser.py` | Parse numbered multiple-choice answers without treating tooth numbers as option numbers. |

The core functions were extracted from the experiment source. `PROVENANCE.json`
records source checksums and extraction scope without private filesystem paths.
The demo, tests, packaging, and explanatory documentation were added for review.

This is a **selected core-code release**, not the complete training and evaluation
environment. It does not include landmark training/evaluation, full mesh rendering,
model-specific inference adapters, or the open-ended-answer judge and its complete
aggregation pipeline. In particular, it must not be used as a replacement for the
full released protocol to regenerate all manuscript tables. The supplementary
material specifies the corresponding prompts, settings, and score definitions.

## Data, annotators, and ethics

The de-identified raw STL scans and detailed professional qualifications of the
annotation personnel will be made public with the final publication. During
double-blind review, this repository provides code and synthetic examples only.
The annotation team comprises two orthodontists with more than eight years of
clinical experience and five master's students in orthodontics, as described in
the manuscript; identifying affiliations and detailed credentials are deferred
to the final version.

As stated in the manuscript, the study received ethics approval and informed
consent was obtained. To preserve double-blind review, the ethics committee's
identifying details and the specific approval number will be disclosed in the
final publication. This postpones disclosure of identifiers, not ethics review.

## Input and scoring notes

See `docs/PROTOCOL_NOTES.md` for coordinate conventions, matching, missing targets,
and the limits of this compact package. Test inputs in `tests/` and the demo are
generated from small arrays, not derived from patient geometry.

## Repository use

Upload only the contents of this directory to the anonymous repository. No Git
history is included. The final data distribution and license terms will accompany
the final release; no license for unreleased clinical data is implied here.
