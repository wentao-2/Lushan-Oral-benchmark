# Protocol notes for the included code

## Splits and input variants

`grouped_splits(rows, anchors)` expects anonymous `case_id` values and optionally
`original_stl_sha256` / `mesh_key` values. It keeps linked cases together and
inherits frozen landmark memberships. Conflicting memberships are quarantined.
The demo illustrates this policy with fabricated IDs. Regenerating assignments
after renaming real IDs can change hash-based assignments: use the frozen split
manifest for real experiments, rather than reconstructing it from renamed IDs.

Tooth-removal candidates use anatomical FDI adjacency, including across the
central incisors. At least six teeth remain. Training requests an original input
with probability 1/2 and each of four removal types with probability 1/8. An
unavailable request falls back to the original scan. Remaining teeth keep their
original labels; no renumbering or remeshing is performed. Partial-arch face
selection uses float64 geometry and a fixed plane. `kept_original_face_ids` checks
both the expected face count and the checksum of the retained original indices.

## Level 1

`score` consumes original-order face-instance arrays, instance-to-FDI mappings,
supernumerary flags, and a valid-face mask. Geometry matching maximizes admissible
matches at IoU >= 0.5, then overlap. FDI labels do not guide matching. Unknown or
supernumerary FDI instances follow the frozen numbering exclusion rule.

Tooth accuracy counts correctly segmented and numbered reference teeth. Joint
F1 also penalizes extra predicted instances. The manuscript's Scan Acc. averages
`joint.scan_correct` over scans: every scored reference tooth must be correctly
matched and numbered. Extra instances do not change this flag. The additional
`joint.strict_scan_correct` flag also requires no extra predictions.
`joint.exact_scan_correct` retains the frozen scorer's strict definition for
backward compatibility; use `scan_correct` for the manuscript's Scan Acc.
For example, recovering all reference teeth and adding one extra instance gives
Scan Acc. = 100%, Strict Scan Acc. = 0%, and joint F1 below 100% for that scan.
`retained_baseline` restricts an original-input result to the same retained teeth;
do not compare removal scores with a different original tooth denominator.

## Level 2

The response uses `fdi` and/or `pixel_xy`, depending on the task. The name
`pixel_xy` is retained from the frozen protocol, but response coordinates are on
the **0--1000 scale**, with 0 <= x,y < 1000. They are multiplied by 0.512 and
floored to index the original **512 x 512** mask. Do not supply coordinates from
a resized image. An absent target requires an explicit `null` location.

Examples:

```json
{"fdi": 21, "pixel_xy": [500, 500]}
```

```json
{"fdi": 21, "pixel_xy": null}
```

`score_answer` returns per-response flags. Visible-target Joint requires both the
correct FDI and a hit on the target mask. Its `joint_correct` field can also be
true for a removed target with correct FDI and refusal; that is the Joint-all
convention, not the visible-target Joint reported in the main comparison.
Aggregation must select the correct denominator. Format validity is not accuracy.
Response/refusal balanced accuracy is the mean of response rate on visible targets
and refusal rate on removed targets; it does not test point correctness.

## Level 3

`parse(text, labels)` returns a 1-based option index or None. Labels must retain
the order shown to the model. It is a multiple-choice parser, not an open-answer
clinical judge. The main open-ended score additionally requires reference findings,
blinded stance extraction and the published aggregation rules; those components
are outside this compact package. An empty answer must not receive normal-target
credit merely because no abnormality was mentioned.
